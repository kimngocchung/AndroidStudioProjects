package com.example.myapplication

data class StudentModel(
    var studentName: String,
    var studentId: String
)